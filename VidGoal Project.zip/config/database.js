if(process.env.NODE_ENV === 'production'){
    module.exports = {mongoURI: 'mongodb+srv://vini:vini1234@vinidb.zfns6.mongodb.net/<dbname>?retryWrites=true&w=majority'}
  } else {
    module.exports = {mongoURI: 'mongodb://localhost/vidjot-dev'}
  }